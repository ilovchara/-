export const ResTypeOther = {
    Stats: {
        lastAccessedTime: 'number',
        lastModifiedTime: 'number',
        mode: 'number',
        size: 'number',
    },
};
