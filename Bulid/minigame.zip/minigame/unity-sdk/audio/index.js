import innerAudio from './inner-audio';
import unityAudio from './unity-audio';
import common from './common';
export default {
    ...innerAudio,
    ...unityAudio,
    ...common,
};
