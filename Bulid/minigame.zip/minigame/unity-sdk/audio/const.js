export const INNER_AUDIO_UNDEFINED_MSG = 'InnerAudioContext does not exist!';
export const IGNORE_ERROR_MSG = 'audio is playing, don\'t play again';
export const TEMP_DIR_PATH = `${wx.env.USER_DATA_PATH}/__GAME_FILE_CACHE/audios`;
