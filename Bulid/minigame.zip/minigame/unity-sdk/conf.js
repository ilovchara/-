export const MODULE_NAME = 'WXSDKManagerHandler';
